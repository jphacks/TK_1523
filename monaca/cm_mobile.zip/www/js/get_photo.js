// This is a JavaScript file
function getphoto() {
    ncmb.File.download("marker_icon.png")
    .then(function(fileData){
      // ファイル取得後処理
     })
    .catch(function(err){
      // エラー処理
     });
}
