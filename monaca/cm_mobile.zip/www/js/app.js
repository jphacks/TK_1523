// This is a JavaScript file

$(function(){
    //起動時にmobile backend APIキーを設定
    $.getJSON("setting.json", function(data) {
        NCMB.initialize(
            data.application_key,
            data.client_key
        );
    });
});
