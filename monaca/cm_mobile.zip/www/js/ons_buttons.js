// This is a JavaScript file

ons.bootstrap()
  .controller("ButtonsController", function($scope) {
    $scope.spin1 = false;
    $scope.spin2 = false;
    $scope.spin3 = false;
    $scope.switchSpin1 = function() {
      $scope.spin1 = ($scope.spin1 == false);
    }
    $scope.switchSpin2 = function() {
      $scope.spin2 = ($scope.spin2 == false);
    }
    $scope.switchSpin3 = function() {
      $scope.spin3 = ($scope.spin3 == false);
    }
  });